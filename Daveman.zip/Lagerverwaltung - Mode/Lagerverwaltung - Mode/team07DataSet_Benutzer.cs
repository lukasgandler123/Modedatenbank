﻿namespace Lagerverwaltung___Mode {
    
    
    public partial class team07DataSet_Benutzer {
    }
}
