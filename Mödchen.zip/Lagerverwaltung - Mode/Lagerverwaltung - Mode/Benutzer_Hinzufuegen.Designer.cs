﻿namespace Lagerverwaltung___Mode
{
    partial class Benutzer_Hinzufuegen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Anlegen = new System.Windows.Forms.Button();
            this.btn_Abbrechen = new System.Windows.Forms.Button();
            this.lbl_Vorname = new System.Windows.Forms.Label();
            this.lbl_Nachname = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_Telefon = new System.Windows.Forms.Label();
            this.lbl_rolle = new System.Windows.Forms.Label();
            this.lbl_Benutzername = new System.Windows.Forms.Label();
            this.lbl_Passwort = new System.Windows.Forms.Label();
            this.lbl_PasswortBestaetigen = new System.Windows.Forms.Label();
            this.txt_Vorname = new System.Windows.Forms.TextBox();
            this.txt_Nachname = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.txt_Telefon = new System.Windows.Forms.TextBox();
            this.txt_Benutzername = new System.Windows.Forms.TextBox();
            this.txt_Passwort = new System.Windows.Forms.TextBox();
            this.txt_PasswortBestaetigen = new System.Windows.Forms.TextBox();
            this.cmb_Rolle = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btn_Anlegen
            // 
            this.btn_Anlegen.Location = new System.Drawing.Point(12, 229);
            this.btn_Anlegen.Name = "btn_Anlegen";
            this.btn_Anlegen.Size = new System.Drawing.Size(166, 65);
            this.btn_Anlegen.TabIndex = 0;
            this.btn_Anlegen.Text = "Anlegen";
            this.btn_Anlegen.UseVisualStyleBackColor = true;
            this.btn_Anlegen.Click += new System.EventHandler(this.btn_Anlegen_Click);
            // 
            // btn_Abbrechen
            // 
            this.btn_Abbrechen.Location = new System.Drawing.Point(184, 229);
            this.btn_Abbrechen.Name = "btn_Abbrechen";
            this.btn_Abbrechen.Size = new System.Drawing.Size(174, 65);
            this.btn_Abbrechen.TabIndex = 1;
            this.btn_Abbrechen.Text = "Abbrechen";
            this.btn_Abbrechen.UseVisualStyleBackColor = true;
            this.btn_Abbrechen.Click += new System.EventHandler(this.btn_Abbrechen_Click);
            // 
            // lbl_Vorname
            // 
            this.lbl_Vorname.AutoSize = true;
            this.lbl_Vorname.Location = new System.Drawing.Point(12, 12);
            this.lbl_Vorname.Name = "lbl_Vorname";
            this.lbl_Vorname.Size = new System.Drawing.Size(49, 13);
            this.lbl_Vorname.TabIndex = 2;
            this.lbl_Vorname.Text = "Vorname";
            // 
            // lbl_Nachname
            // 
            this.lbl_Nachname.AutoSize = true;
            this.lbl_Nachname.Location = new System.Drawing.Point(12, 38);
            this.lbl_Nachname.Name = "lbl_Nachname";
            this.lbl_Nachname.Size = new System.Drawing.Size(59, 13);
            this.lbl_Nachname.TabIndex = 3;
            this.lbl_Nachname.Text = "Nachname";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Location = new System.Drawing.Point(12, 64);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(36, 13);
            this.lbl_email.TabIndex = 4;
            this.lbl_email.Text = "E-Mail";
            // 
            // lbl_Telefon
            // 
            this.lbl_Telefon.AutoSize = true;
            this.lbl_Telefon.Location = new System.Drawing.Point(12, 90);
            this.lbl_Telefon.Name = "lbl_Telefon";
            this.lbl_Telefon.Size = new System.Drawing.Size(43, 13);
            this.lbl_Telefon.TabIndex = 5;
            this.lbl_Telefon.Text = "Telefon";
            // 
            // lbl_rolle
            // 
            this.lbl_rolle.AutoSize = true;
            this.lbl_rolle.Location = new System.Drawing.Point(12, 116);
            this.lbl_rolle.Name = "lbl_rolle";
            this.lbl_rolle.Size = new System.Drawing.Size(31, 13);
            this.lbl_rolle.TabIndex = 6;
            this.lbl_rolle.Text = "Rolle";
            // 
            // lbl_Benutzername
            // 
            this.lbl_Benutzername.AutoSize = true;
            this.lbl_Benutzername.Location = new System.Drawing.Point(12, 142);
            this.lbl_Benutzername.Name = "lbl_Benutzername";
            this.lbl_Benutzername.Size = new System.Drawing.Size(75, 13);
            this.lbl_Benutzername.TabIndex = 7;
            this.lbl_Benutzername.Text = "Benutzername";
            // 
            // lbl_Passwort
            // 
            this.lbl_Passwort.AutoSize = true;
            this.lbl_Passwort.Location = new System.Drawing.Point(12, 168);
            this.lbl_Passwort.Name = "lbl_Passwort";
            this.lbl_Passwort.Size = new System.Drawing.Size(50, 13);
            this.lbl_Passwort.TabIndex = 8;
            this.lbl_Passwort.Text = "Passwort";
            // 
            // lbl_PasswortBestaetigen
            // 
            this.lbl_PasswortBestaetigen.AutoSize = true;
            this.lbl_PasswortBestaetigen.Location = new System.Drawing.Point(12, 194);
            this.lbl_PasswortBestaetigen.Name = "lbl_PasswortBestaetigen";
            this.lbl_PasswortBestaetigen.Size = new System.Drawing.Size(102, 13);
            this.lbl_PasswortBestaetigen.TabIndex = 9;
            this.lbl_PasswortBestaetigen.Text = "Passwort bestätigen";
            // 
            // txt_Vorname
            // 
            this.txt_Vorname.Location = new System.Drawing.Point(142, 9);
            this.txt_Vorname.Name = "txt_Vorname";
            this.txt_Vorname.Size = new System.Drawing.Size(216, 20);
            this.txt_Vorname.TabIndex = 10;
            // 
            // txt_Nachname
            // 
            this.txt_Nachname.Location = new System.Drawing.Point(142, 35);
            this.txt_Nachname.Name = "txt_Nachname";
            this.txt_Nachname.Size = new System.Drawing.Size(216, 20);
            this.txt_Nachname.TabIndex = 11;
            // 
            // txt_Email
            // 
            this.txt_Email.Location = new System.Drawing.Point(142, 61);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(216, 20);
            this.txt_Email.TabIndex = 12;
            // 
            // txt_Telefon
            // 
            this.txt_Telefon.Location = new System.Drawing.Point(142, 87);
            this.txt_Telefon.Name = "txt_Telefon";
            this.txt_Telefon.Size = new System.Drawing.Size(216, 20);
            this.txt_Telefon.TabIndex = 13;
            // 
            // txt_Benutzername
            // 
            this.txt_Benutzername.Location = new System.Drawing.Point(142, 139);
            this.txt_Benutzername.Name = "txt_Benutzername";
            this.txt_Benutzername.Size = new System.Drawing.Size(216, 20);
            this.txt_Benutzername.TabIndex = 15;
            // 
            // txt_Passwort
            // 
            this.txt_Passwort.Location = new System.Drawing.Point(142, 165);
            this.txt_Passwort.Name = "txt_Passwort";
            this.txt_Passwort.PasswordChar = '*';
            this.txt_Passwort.Size = new System.Drawing.Size(216, 20);
            this.txt_Passwort.TabIndex = 16;
            // 
            // txt_PasswortBestaetigen
            // 
            this.txt_PasswortBestaetigen.Location = new System.Drawing.Point(142, 191);
            this.txt_PasswortBestaetigen.Name = "txt_PasswortBestaetigen";
            this.txt_PasswortBestaetigen.PasswordChar = '*';
            this.txt_PasswortBestaetigen.Size = new System.Drawing.Size(216, 20);
            this.txt_PasswortBestaetigen.TabIndex = 17;
            // 
            // cmb_Rolle
            // 
            this.cmb_Rolle.FormattingEnabled = true;
            this.cmb_Rolle.Location = new System.Drawing.Point(142, 112);
            this.cmb_Rolle.Name = "cmb_Rolle";
            this.cmb_Rolle.Size = new System.Drawing.Size(216, 21);
            this.cmb_Rolle.TabIndex = 18;
            // 
            // Benutzer_Hinzufuegen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 305);
            this.Controls.Add(this.cmb_Rolle);
            this.Controls.Add(this.txt_PasswortBestaetigen);
            this.Controls.Add(this.txt_Passwort);
            this.Controls.Add(this.txt_Benutzername);
            this.Controls.Add(this.txt_Telefon);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.txt_Nachname);
            this.Controls.Add(this.txt_Vorname);
            this.Controls.Add(this.lbl_PasswortBestaetigen);
            this.Controls.Add(this.lbl_Passwort);
            this.Controls.Add(this.lbl_Benutzername);
            this.Controls.Add(this.lbl_rolle);
            this.Controls.Add(this.lbl_Telefon);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_Nachname);
            this.Controls.Add(this.lbl_Vorname);
            this.Controls.Add(this.btn_Abbrechen);
            this.Controls.Add(this.btn_Anlegen);
            this.Name = "Benutzer_Hinzufuegen";
            this.Text = "Benutzer Anlegen";
            this.Load += new System.EventHandler(this.Benutzer_Hinzufuegen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Anlegen;
        private System.Windows.Forms.Button btn_Abbrechen;
        private System.Windows.Forms.Label lbl_Vorname;
        private System.Windows.Forms.Label lbl_Nachname;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_Telefon;
        private System.Windows.Forms.Label lbl_rolle;
        private System.Windows.Forms.Label lbl_Benutzername;
        private System.Windows.Forms.Label lbl_Passwort;
        private System.Windows.Forms.Label lbl_PasswortBestaetigen;
        private System.Windows.Forms.TextBox txt_Vorname;
        private System.Windows.Forms.TextBox txt_Nachname;
        private System.Windows.Forms.TextBox txt_Email;
        private System.Windows.Forms.TextBox txt_Telefon;
        private System.Windows.Forms.TextBox txt_Benutzername;
        private System.Windows.Forms.TextBox txt_Passwort;
        private System.Windows.Forms.TextBox txt_PasswortBestaetigen;
        private System.Windows.Forms.ComboBox cmb_Rolle;
    }
}